#include <iostream>
using namespace std;

class ThreeDimShape
{
public:
    virtual double getArea()  = 0;
    virtual double getVolume()  = 0;
};
class Ball:public ThreeDimShape
{
public:
    Ball(double r):radius(r) {}
    virtual double getArea()
    {
        return 4 * 3.14159 * radius * radius;
    }
    virtual double getVolume()
    {
        return 4.0 / 3.0 *3.14159 * radius * radius * radius;
    }
protected:
    double radius;
};
class Cylinder:public ThreeDimShape
{
public:
    Cylinder(double r,double h):radius(r),height(h) {}
    virtual double getArea()
    {
        return 2 * 3.14159 * radius * radius + 2 * 3.14159 * radius * height;
    }
    virtual double getVolume()
    {
        return 3.14159 * radius * radius * height;
    }
private:
    double radius;
    double height;
};
int main()
{
    ThreeDimShape * shape[2];
    Ball ball(3.6);
    Cylinder cylinder(3.8,6.9);
    shape[0] = &ball;
    shape[1] = &cylinder;
    for(int i = 0;i < 2;i++)
    {
        cout << shape[i] -> getArea() << " ";
        cout << shape[i] -> getVolume() << endl;
    }
    return 0;
}
