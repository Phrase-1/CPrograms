/*
#include <iostream>
#include <string>
using namespace std;

class Student
{
public:
    Student(int n,string nam):num(n),name(nam)
    {
        count++;
    }
    Student(const Student &stu):num(stu.num),name(stu.name)
    {
        count++;
    }
    static int total()
    {
        return count;//��̬���ݳ�Ա��������ģ��������ڶ����
    }
    ~Student()
    {
        count--;
    }
private:
    int num;
    string name;
    static int count;
};
int Student::count = 0;
int main()
{
    Student stu1(201601,"zhangsan");
    Student stu2(stu1);
    Student *pStu1 = new Student(201602,"lisi");
    cout << Student::total() << endl;//��̬��Ա���������һ���֣������Ƕ����һ����
    cout << stu1.total() << endl;//ʹ�ö���Ҳ���Է��ʾ�̬��Ա����
    cout << stu2.total() << endl;
    Student *pStu2 = &stu2;
    delete pStu2;
    cout << Student::total() << endl;
    return 0;
}
*/

/*
#include <iostream>
using namespace std;

class Sample
{
public:
    Sample(int x):n(x) {}
    void add() {sum += n;}
    void display(){cout << "n = " << n << ",sum = " << sum << endl;}
private:
    int n;
    static int sum;

};
int Sample::sum = 0;
int main()
{
    Sample s1(2),s2(3),s3(5);
    s1.add();
    s1.display();
    s2.add();
    s2.display();
    s3.add();
    s3.display();
    return 0;
}
*/


/*
#include <iostream>
using namespace std;

class Sample
{
    int A;
    static int B;
public:
    Sample(int a)
    {
        A = a;
        B += a;
    }
    static void func(Sample s);
};
void Sample::func(Sample s)
{
    cout << "A = " << s.A << ",B = " << B << endl;
}
int Sample::B = 0;
int main()
{
    Sample s1(2),s2(5);
    Sample::func(s1);
    Sample::func(s2);
    return 0;
}
*/


/*
#include <iostream>
using namespace std;

class Counter
{
    static int num;
public:
    void setnum(int i) {num = i;}
    void shownum() {cout << num << "\t";}
};
int Counter::num = 0;
int main()
{
    Counter a,b;
    a.shownum();
    b.shownum();
    a.setnum(10);
    a.shownum();
    b.shownum();
    return 0;
}
*/

