/*�����๹�캯����ִ��˳��1.���๹�캯��2.�Ӷ����캯����û����������3.���캯���ĺ�����*/
/*
#include <iostream>
using namespace std;

class Point
{
public:
    Point():m_nX(0),m_nY(0) {}
    Point(int x):m_nX(x),m_nY(0) {}
    Point(int x,int y):m_nX(x),m_nY(y) {}
    void show()const {cout << m_nX << " " << m_nY << " ";}
protected:
    int m_nX,m_nY;
};
class Circle:public Point
{
public:
    Circle(int r):radius(r) {}//��ʽ�Զ����û���Ĭ�Ϲ��캯��
    Circle(int a,int r):Point(a),radius(r) {}
    Circle(int a,int b,int r):Point(a,b),radius(r) {}
    void show()const
    {
        Point::show();
        cout << "radius = " << radius << endl;
    }
protected:
    int radius;
};
int main()
{
    Circle c1(2),c2(3,4),c3(1,2,5);
    c1.show();
    c2.show();
    c3.show();
    return 0;
}
*/





/*
#include <iostream>
using namespace std;

class Sample
{
protected:
    int x;
public:
    Sample():x(0) {}
    Sample(int val):x(val) {}
    void operator++(int) {x++;}//�Ժ������������������
};
class Derived:public Sample
{
    int y;
public:
    Derived():Sample(),y(0) {}
    Derived(int val1,int val2):Sample(val1),y(val2) {}
    void operator--(int) {x--;y--;}
    void disp()
    {
        cout << "x = " << x << ",y = " << y << endl;
    }
};
int main()
{
    Derived d(3,5);
    d.disp();
    d++;
    d.disp();
    d--;
    d--;
    d.disp();
    return 0;
}
*/






/*
#include <iostream>
using namespace std;

class A
{
    int a;
public:
    A(int i):a(i) {cout << "constructing class A" << endl;}
    void print() {cout << a << endl;}
    ~A() {cout << "destructing class A" << endl;}
};
class B1:public A
{
    int b1;
public:
    B1(int i,int j):A(i),b1(j){cout << "constructing class B1" << endl;}
    void print()
    {
        A::print();
        cout << b1 << endl;
    }
    ~B1() {cout << "destructing class B1" << endl;}
};
class B2:public A
{
    int b2;
public:
    B2(int i,int j):A(i),b2(j){cout << "constructing class B2" << endl;}
    void print()
    {
        A::print();
        cout << b2 << endl;
    }
    ~B2() {cout << "destructing class B2" << endl;}
};
class C:public B1,public B2
{
    int c;
public:
    C(int i,int j,int k,int l,int m):B1(i,j),B2(k,l),c(m)
    {
        cout << "constructing class C" << endl;
    }
    void print()
    {
        B1::print();
        B2::print();
        cout << c << endl;
    }
    ~C() {cout << "destructing class C" << endl;}
};
int main()
{
    C c1(1,2,3,4,5);
    c1.print();
    return 0;
}
*/





/*
#include <iostream>
using namespace std;
class A
{
public:
    A(char *s) {cout << s << endl;}
    ~A() {}
};
class B:public A
{
public:
    B(char *s1,char *s2):A(s1) {cout << s2 << endl;}
};
class C:public A
{
public:
    C(char *s1,char *s2):A(s1) {cout << s2 << endl;}
};
class D:public B,public C
{
public:
    D(char *s1,char *s2,char *s3,char *s4):B(s1,s2),C(s1,s3) {cout << s4 << endl;}
};
int main()
{
    D d("class A","class B","class C","class D");
    return 0;
}
*/





/*
#include <iostream>
using namespace std;
class A
{
public:
    A(char *s) {cout << s << endl;}
    ~A() {}
};
class B:virtual public A
{
public:
    B(char *s1,char *s2):A(s1) {cout << s2 << endl;}
};
class C:virtual public A
{
public:
    C(char *s1,char *s2):A(s1) {cout << s2 << endl;}
};
class D:public B,public C
{
public:
    D(char *s1,char *s2,char *s3,char *s4):B(s1,s2),C(s1,s3),A(s1) {cout << s4 << endl;}
};
int main()
{
    D d("class A","class B","class C","class D");
    return 0;
}
*/
