#include <iostream>
#include "list.h"
using namespace std;

int main()
{
    List l;
	l.Append(1);
	l.Prepend(10);
	int s;
	l.Find(s, 2);
	l.Remove(s, 2);
	l.PrintList();
	return 0;
}
