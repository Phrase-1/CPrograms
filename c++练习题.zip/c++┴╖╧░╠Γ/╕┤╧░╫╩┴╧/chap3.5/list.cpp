#include <iostream>
using namespace std;
#include "List.h"

List::List() //���캯��
{
	m_pFirst = new Node();
}
List::~List() //���캯��
{
	Node * p = m_pFirst;
	Node * q;
	while (NULL != p) //Ѱ��inedexλ��ǰһ���ڵ�
	{
		q = p;
		p = p->m_pNext;
		delete q;
	}
}
bool List::Append(const int &e, int index) //��inedexλ�ú����ӽڵ�
{
	if (index < 0)
	{
		return false;
	}
	Node *p = m_pFirst;
	int i = 0;
	while (NULL != p && i < index) //Ѱ��inedexλ�ô��ڵ�
	{
		++i;
		p = p->m_pNext;
	}
	if (NULL == p)
	{
		return false;
	}
	Node *q = new Node(e, p->m_pNext);
	p->m_pNext = q;
	return true;
}
bool List::Prepend(const int &e, int index) //��inedexλ��ǰ���ӽڵ�
{
	if (index < 1)
	{
		return false;
	}
	Node *p = m_pFirst;
	int i = 0;
	while (NULL != p && i < index - 1) //Ѱ��inedexλ��ǰһ���ڵ�
	{
		++i;
		p = p->m_pNext;
	}
	if (NULL == p)
	{
		return false;
	}
	Node *q = new Node(e, p->m_pNext);
	p->m_pNext = q;
	return true;
}
bool List::Remove(int &e, int index) //ɾ��inedexλ�ô��Ľڵ�
{
	if (index < 1)
	{
		return false;
	}
	Node *p = m_pFirst;
	int i = 0;
	while (NULL != p && i < index - 1) //Ѱ��inedexλ��ǰһ���ڵ�
	{
		++i;
		p = p->m_pNext;
	}
	if (p == NULL || NULL == p->m_pNext)
	{
		return false;
	}
	Node *q = p->m_pNext;
	p->m_pNext = q->m_pNext;
	e = q->m_nData;
	delete q;
	return true;
}
bool List::Find(int &e, int index) //����inedexλ�ô��Ľڵ㡡
{
	if (index < 1)
	{
		return false;
	}
	Node *p = m_pFirst;
	int i = 0;
	while (NULL != p && i < index) //Ѱ��inedexλ�ô��ڵ�
	{
		++i;
		p = p->m_pNext;
	}
	if (NULL == p)
	{
		return false;
	}
	e = p->m_nData;
	return true;
}
void List::PrintList() //��ӡ����
{
	Node *p = m_pFirst->m_pNext;
	while (NULL != p) //Ѱ��inedexλ�ô��ڵ�
	{
		cout << p->m_nData << '\t';
		p = p->m_pNext;
	}
	cout << endl;
}
