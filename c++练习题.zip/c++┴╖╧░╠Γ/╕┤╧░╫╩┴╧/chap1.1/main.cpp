/*
#include <iostream>
using namespace std;

//�α�1.12���á������βΡ�ʵ������������ֵ����
void swap(int &a,int &b)
{
    int temp;
    temp = a;
    a = b;
    b = temp;
}
int main()
{
    int i = 3,j = 5;
    swap(i,j);
    cout << "i = " << i << "," << "j = " << j << endl;
    return 0;
}
*/

/*
#include <iostream>
using namespace std;

class Sample
{
    int x,y;
public:
    Sample():x(0),y(0) {}
    Sample(int i,int j):x(i),y(j) {}
    void copy(Sample &s)
    {
        x = s.x;
        y = s.y;
    }
    void setxy(int i,int j)
    {
        x = i;
        y = j;
    }
    void print()
    {
        cout << "x = " << x << ",y = " << y << endl;
    }
};
void func(Sample s1,Sample &s2)
{
    s1.setxy(10,20);
    s2.setxy(30,40);
}
int main()
{
    Sample p(1,2),q;
    q.copy(p);
    func(p,q);
    p.print();
    q.print();
    return 0;
}
*/

/*
#include <iostream>
using namespace std;

class Sample
{
    int x;
public:
    Sample() {}
    Sample(int a):x(a) {}
    Sample(Sample &a) {x = a.x++ + 10;}//ע�⣺x��ʹ�ã�����ֵ��
    void disp() {cout << "x = " << x << endl;}
};
int main()
{
    Sample s1(2),s2(s1);
    s1.disp();
    s2.disp();
    return 0;
}
*/
