#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED
class Stack
{
    int *m_Elem;
    int m_nTop;
    const int m_nSize;
public:
    Stack(int size):m_nTop(0),m_nSize(size)
    {
        m_Elem = new int[m_nSize];
    }
    bool IsEmpty()
    {
        return m_nTop == 0;
    }
    bool IsFull()
    {
        return m_nTop == m_nSize;
    }
    bool Push(int e);
    bool Pop(int &e);
};

#endif // STACK_H_INCLUDED
