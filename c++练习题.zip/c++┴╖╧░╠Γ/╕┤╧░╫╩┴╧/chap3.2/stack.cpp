#include "stack.h"

bool Stack::Push(int e)
{
    if(IsFull())
        return false;
    else
    {
        m_Elem[m_nTop] = e;
        ++m_nTop;
        return true;
    }
}
bool Stack::Pop(int &e)
{
    if(IsEmpty())
        return false;
    else
    {
        --m_nTop;
        e = m_Elem[m_nTop];
        return true;
    }
}

