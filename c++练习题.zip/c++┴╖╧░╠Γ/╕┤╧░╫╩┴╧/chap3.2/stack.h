/*
const int SIZE = 4;
class Stack
{
    int m_Elem[SIZE];
    int m_nTop;//ջ��λ��
    const int m_nSize;//����
public:
    Stack():m_nTop(0),m_nSize(SIZE) {}
    bool IsEmpty() {return m_nTop == 0;}
    bool IsFull() {return m_nTop == m_nSize;}
    bool Push(int e);
    bool Pop(int &e);
};
*/
class Stack
{
public:
    Stack(int size):m_nTop(0),m_nSize(size)
    {
        m_Elem = new int[m_nSize];
    }
    bool IsEmpty() {return m_nTop == 0;}
    bool IsFull() {return m_nTop == m_nSize;}
    bool Push(int e);
    bool Pop(int &e);
    ~Stack() {delete[] m_Elem;}
private:
    int *m_Elem;
    int m_nTop;
    const int m_nSize;
};
