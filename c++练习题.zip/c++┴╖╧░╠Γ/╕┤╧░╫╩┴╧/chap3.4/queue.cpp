#include "Queue.h"

bool Queue::EnQueue(int v)
{
    if(IsFull())
        return false;
    else
    {
        data[rear] = v;
        rear = (rear + 1) % (size + 1);
        return true;
    }
}
bool Queue::DeQueue(int &v)
{
    if(IsEmpty())
        return false;
    else
    {
        v = data[front];
        front = (front + 1) % (size + 1);
        return true;
    }
}
