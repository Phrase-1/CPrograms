#ifndef QUEUE_H_INCLUDED
#define QUEUE_H_INCLUDED

class Queue//����ʵ��ѭ������ջ
{
    int front,rear;
    int *data;
    const int size;
public:
    Queue(int s):front(0),rear(0),size(s)
    {
        data = new int[size + 1];
    }
    bool IsEmpty() {return rear = front;}
    bool IsFull() {return (rear + 1) % (size + 1) == front;}
    bool EnQueue(int v);
    bool DeQueue(int &v);
    ~Queue()
    {
        delete[] data;
    }
};
#endif // QUEUE_H_INCLUDED
